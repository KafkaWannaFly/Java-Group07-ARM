package Models;

public class Manager extends User{
    public Manager(){}

    //SETTER
    public void setUsername(){}
    public void setPassword(){}
    public void setSalary(){}

    //GETTER
    public String getPassword(){
        return password;
    }

    //Function
    public void AddEmployee(){}
    public void SearchEmployee(){}
    public void RemoveEmployee(){}
}
