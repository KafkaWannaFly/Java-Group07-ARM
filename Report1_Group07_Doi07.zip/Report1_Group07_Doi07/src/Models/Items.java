package Models;

public class Items {
    private String name;
    private Long price;
    private String imgPath;

    public Items(){}

    //SETTER
    public void setName(){}
    public void setPrice(){}
    public void setImgPath(){}

    //GETTER
    public String getName(){
        return name;
    }
    public Long getPrice(){
        return price;
    }
    public String getImgPath(){
        return imgPath;
    }
}
