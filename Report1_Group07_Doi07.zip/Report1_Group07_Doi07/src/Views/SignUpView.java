package Views;

import javax.swing.*;

public class SignUpView {
	private JPanel root;
	private JPanel loginLabelGroup;
	private JPanel form;
	private JPanel userNameGroup;
	private JPanel dobGroup;
	private JPanel nameGroup;
	private JPanel genderGroup;
	private JTextField usernameInput;
	private JPasswordField passwordInput;
}
