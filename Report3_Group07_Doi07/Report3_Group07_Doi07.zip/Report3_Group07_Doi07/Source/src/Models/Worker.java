package Models;

public class Worker extends User{
    public Worker(){}
}
