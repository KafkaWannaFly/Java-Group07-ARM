package Views;

import javax.swing.*;
import java.awt.*;

public class EmployeesView {
	private JPanel rootPane;

	public JPanel getRootPane() {
		return rootPane;
	}

}
