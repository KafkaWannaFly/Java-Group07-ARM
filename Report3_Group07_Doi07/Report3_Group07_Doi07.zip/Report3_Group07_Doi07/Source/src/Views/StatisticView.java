package Views;

import javax.swing.*;
import java.awt.*;

public class StatisticView {
	private JPanel rootPane;

	public JPanel getRootPane() {
		return rootPane;
	}

}
