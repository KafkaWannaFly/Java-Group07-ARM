package Views;

import javax.swing.*;
import java.awt.*;

public class MembershipView {
	private JPanel rootPane;

	public JPanel getRootPane() {
		return rootPane;
	}

}
